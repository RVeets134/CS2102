class MassStartResult extends AbsSkiingEvent {
	
	MassStartResult(double time, int position) {
		super(time, position);
	}

}