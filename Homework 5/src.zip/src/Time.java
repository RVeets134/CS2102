
class Time {

	private int hour;
	private int minute;
	
	Time(int hour, int minute) {
		this.hour = hour;
		this.minute = minute;
	}

	int getHour() {
		return hour;
	}

	int getMinute() {
		return minute;
	}
	
}
