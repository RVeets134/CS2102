
interface IDailyReport {

	int getHigh();

	int getLow();

}
