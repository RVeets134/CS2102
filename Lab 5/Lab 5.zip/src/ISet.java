
interface ISet {
	
	ISet addElt(String elt);
	
	boolean hasElt(String elt);
	
	int size();

}
