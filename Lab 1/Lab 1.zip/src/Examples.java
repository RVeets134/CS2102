
import static org.junit.Assert.*;
import org.junit.Test;

public class Examples {

    public Examples(){}
    
    /*
    // This shows what a test case looks like
    @Test 
    public void simpleCheck() {
	assertEquals(4, 4);
    }
    */
    
    Song song1 = new Song("Song 1",14);
    Song song2 = new Song("Song 2",6);
    
    @Test
    public void checkSong1Len() {
    	assertEquals(14,song1.lenInSeconds);
    }
    
    @Test
    public void checkSong2Len() {
    	assertEquals(14,song2.lenInSeconds);
    }
  
}