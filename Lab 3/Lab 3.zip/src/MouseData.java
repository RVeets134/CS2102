import java.util.LinkedList;

class MouseData {

	LinkedList<Double> weight;
	LinkedList<String> date;
	
	MouseData(){}
	
}
