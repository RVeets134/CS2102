import java.util.LinkedList;

class Experiment {

	int numberOfMice;
	LinkedList<Mouse> mice;
	
}
