
interface IEvent {
	
	public double pointsEarned();
	
}
