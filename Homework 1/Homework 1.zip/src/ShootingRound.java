
class ShootingRound {
	
	int targetsHit;
	
	ShootingRound(int hits){
		this.targetsHit = hits;
	}
	
}
